/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto;


import java.util.Arrays;
import java.util.List;


public class Dinic extends AlgoritmoFlujo {

    private int[] nivel;   
    private int[] sig;     
    private Nodo[] cola;
    private Nodo s, t;

    @Override
    public String nombre() { return "Dinic"; }

    @Override
    protected long ejecutar(RedFlujo red) {
        final int n = red.getNumNodos();
        s = red.getNodo(red.getFuente());
        t = red.getNodo(red.getSumidero());
        nivel = new int[n];
        sig = new int[n];
        cola = new Nodo[n];

        long flujoTotal = 0;
        while (construirNiveles(n)) {
            fases++;
            Arrays.fill(sig, 0);
            long f;
            while ((f = enviar(s, Long.MAX_VALUE)) > 0) {
                flujoTotal += f;
                aumentos++;
            }
        }
        return flujoTotal;
    }

 
    private boolean construirNiveles(int n) {
        Arrays.fill(nivel, -1);
        nivel[s.id] = 0;
        int ini = 0, fin = 0;
        cola[fin++] = s;
        while (ini < fin) {
            Nodo u = cola[ini++];
            for (Arista a : u.aristas) {
                aristasExaminadas++;
                if (a.capacidadResidual() > 0 && nivel[a.destino.id] == -1) {
                    nivel[a.destino.id] = nivel[u.id] + 1;
                    cola[fin++] = a.destino;
                }
            }
        }
        return nivel[t.id] != -1;
    }

    private long enviar(Nodo u, long disponible) {
        if (u == t) return disponible;
        List<Arista> lista = u.aristas;
        for (; sig[u.id] < lista.size(); sig[u.id]++) {
            Arista a = lista.get(sig[u.id]);
            aristasExaminadas++;
            long residual = a.capacidadResidual();
            if (residual > 0 && nivel[a.destino.id] == nivel[u.id] + 1) {
                long enviado = enviar(a.destino, Math.min(disponible, residual));
                if (enviado > 0) {
                    a.aumentar(enviado);
                    return enviado;
                }
            }
        }
        return 0;
    }
}