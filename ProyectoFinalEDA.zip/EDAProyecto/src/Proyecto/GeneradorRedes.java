/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto;


import java.util.Random;


public final class GeneradorRedes {

   
    public static final long CAP_ILIMITADA = 1_000_000_000L;

    private GeneradorRedes() { }


    public static RedFlujo aleatoria(int v, double densidad, int capMax, long semilla) {
        Random rnd = new Random(semilla);
        RedFlujo red = new RedFlujo(v, 0, v - 1);
        for (int u = 0; u < v; u++) {
            for (int w = 0; w < v; w++) {
                if (u != w && rnd.nextDouble() < densidad) {
                    red.agregarArista(u, w, 1 + rnd.nextInt(capMax));
                }
            }
        }
        return red;
    }

    public static RedFlujo porCapas(int v, double densidad, long semilla) {
        if (v % 4 != 0) throw new IllegalArgumentException("v debe ser multiplo de 4");
        final int tam = v / 4;
        final int[][] rangos = { {10, 50}, {50, 100}, {100, 200} };
        Random rnd = new Random(semilla);
        RedFlujo red = new RedFlujo(v + 2, v, v + 1);

        for (int i = 0; i < tam; i++) red.agregarArista(v, i, CAP_ILIMITADA);      
        for (int c = 0; c < 3; c++) {
            int ini = c * tam, sigIni = (c + 1) * tam;
            int min = rangos[c][0], max = rangos[c][1];
            for (int a = 0; a < tam; a++) {
                for (int b = 0; b < tam; b++) {
                    if (rnd.nextDouble() < densidad) {
                        red.agregarArista(ini + a, sigIni + b, min + rnd.nextInt(max - min + 1));
                    }
                }
            }
        }
        for (int i = 0; i < tam; i++) red.agregarArista(3 * tam + i, v + 1, CAP_ILIMITADA);
        return red;
    }
}