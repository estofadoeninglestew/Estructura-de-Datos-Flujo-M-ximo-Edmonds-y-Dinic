/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto;

public class Arista {
    public final Nodo origen;
    public final Nodo destino;
    public final long capacidad;
    public long flujo;
    public Arista inversa;

    Arista(Nodo origen, Nodo destino, long capacidad) {
        this.origen = origen;
        this.destino = destino;
        this.capacidad = capacidad;
    }


    public long capacidadResidual() {
        return capacidad - flujo;
    }
    

    public void aumentar(long cantidad) {
        flujo += cantidad;
        inversa.flujo -= cantidad;
    }
}
