/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto;


public class EdmondsKarp extends AlgoritmoFlujo {

    @Override
    public String nombre() { return "Edmonds-Karp"; }

    @Override
    protected long ejecutar(RedFlujo red) {
        final int n = red.getNumNodos();
        final Nodo s = red.getNodo(red.getFuente());
        final Nodo t = red.getNodo(red.getSumidero());

        Arista[] previa = new Arista[n]; 
        int[] marca = new int[n];        
        Nodo[] cola = new Nodo[n];      
        int ronda = 0;
        long flujoTotal = 0;

        while (true) {
            
            ronda++;
            int ini = 0, fin = 0;
            cola[fin++] = s;
            marca[s.id] = ronda;
            while (ini < fin && marca[t.id] != ronda) {
                Nodo u = cola[ini++];
                for (Arista a : u.aristas) {
                    aristasExaminadas++;
                    if (a.capacidadResidual() > 0 && marca[a.destino.id] != ronda) {
                        marca[a.destino.id] = ronda;
                        previa[a.destino.id] = a;
                        cola[fin++] = a.destino;
                    }
                }
            }
            if (marca[t.id] != ronda) break; 

          
            long cuello = Long.MAX_VALUE;
            for (Nodo v = t; v != s; v = previa[v.id].origen)
                cuello = Math.min(cuello, previa[v.id].capacidadResidual());

          
            for (Nodo v = t; v != s; v = previa[v.id].origen)
                previa[v.id].aumentar(cuello);

            flujoTotal += cuello;
            aumentos++;
        }
        return flujoTotal;
    }
}
