/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto;


import java.util.ArrayDeque;
import java.util.Queue;


public class RedFlujo {
    private final Nodo[] nodos;
    private final int fuente;
    private final int sumidero;
    private int numAristas; 

    public RedFlujo(int numNodos, int fuente, int sumidero) {
        if (fuente == sumidero) throw new IllegalArgumentException("fuente == sumidero");
        this.nodos = new Nodo[numNodos];
        for (int i = 0; i < numNodos; i++) nodos[i] = new Nodo(i);
        this.fuente = fuente;
        this.sumidero = sumidero;
    }

 
    public void agregarArista(int u, int v, long capacidad) {
        if (capacidad < 0) throw new IllegalArgumentException("capacidad < 0");
        Arista directa = new Arista(nodos[u], nodos[v], capacidad);
        Arista inversa = new Arista(nodos[v], nodos[u], 0);
        directa.inversa = inversa;
        inversa.inversa = directa;
        nodos[u].aristas.add(directa);
        nodos[v].aristas.add(inversa);
        numAristas++;
    }


    public void reiniciarFlujos() {
        for (Nodo n : nodos) for (Arista a : n.aristas) a.flujo = 0;
    }


    public boolean[] alcanzablesDesdeFuente() {
        boolean[] vis = new boolean[nodos.length];
        Queue<Nodo> cola = new ArrayDeque<>();
        vis[fuente] = true;
        cola.add(nodos[fuente]);
        while (!cola.isEmpty()) {
            Nodo u = cola.poll();
            for (Arista a : u.aristas) {
                if (a.capacidadResidual() > 0 && !vis[a.destino.id]) {
                    vis[a.destino.id] = true;
                    cola.add(a.destino);
                }
            }
        }
        return vis;
    }

    public Nodo getNodo(int i) { return nodos[i]; }
    public int getNumNodos() { return nodos.length; }
    public int getNumAristas() { return numAristas; }
    public int getFuente() { return fuente; }
    public int getSumidero() { return sumidero; }
}