/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto;

import java.util.Arrays;
import java.util.Random;

//Pruebas //
public class Main {

    public static void main(String[] args) {
        AlgoritmoFlujo ek = new EdmondsKarp();
        AlgoritmoFlujo di = new Dinic();

        System.out.println("=== 1) Ejemplos conocidos ===");
        RedFlujo r1 = ejemploSeisNodos();           
        System.out.printf("Ejemplo 6 nodos : EK=%d  Dinic=%d  (esperado 19)%n",
                ek.resolver(r1), di.resolver(r1));
        RedFlujo r2 = ejemploOnceNodos();           
        System.out.printf("Ejemplo 11 nodos: EK=%d  Dinic=%d  (esperado 30)%n",
                ek.resolver(r2), di.resolver(r2));

        System.out.println("\n=== 2) Validacion cruzada en 300 redes aleatorias ===");
        int fallos = 0;
        for (int semilla = 0; semilla < 300; semilla++) {
            int n = 10 + (semilla % 40);
            double dens = 0.05 + 0.05 * (semilla % 10);
            RedFlujo r = redAleatoria(n, dens, 100, semilla);
            long fEk = ek.resolver(r);
            boolean[] corteEk = r.alcanzablesDesdeFuente();
            long aumEk = ek.getAumentos();
            long fDi = di.resolver(r);
            boolean[] corteDi = r.alcanzablesDesdeFuente();
            boolean ok = fEk == fDi && Arrays.equals(corteEk, corteDi)
                    && di.getFases() <= n - 1
                    && aumEk <= ((long) n * n * n - n) / 4;
            if (!ok) { fallos++; System.out.println("FALLO en semilla " + semilla); }
        }
        System.out.println(fallos == 0
                ? "OK: mismo flujo, mismo corte minimo, fases <= V-1 y aumentos <= (V^3-V)/4"
                : "Hubo " + fallos + " fallos");

        System.out.println("\n=== 3) Contadores (densidad 10%, capacidades 1..100) ===");
        System.out.printf("%-6s %-13s %-8s %-9s %-7s %-12s %-10s%n",
                "V", "Algoritmo", "Flujo", "Aumentos", "Fases", "Aristas exam", "ms");
        for (int n : new int[]{100, 200, 400, 800}) {
            RedFlujo r = redAleatoria(n, 0.10, 100, 7);
            for (AlgoritmoFlujo a : new AlgoritmoFlujo[]{ek, di}) {
                a.resolver(r); 
                long ini = System.nanoTime();
                long flujo = a.resolver(r);
                double ms = (System.nanoTime() - ini) / 1e6;
                System.out.printf("%-6d %-13s %-8d %-9d %-7d %-12d %-10.3f%n",
                        n, a.nombre(), flujo, a.getAumentos(), a.getFases(),
                        a.getAristasExaminadas(), ms);
            }
        }
    }

  

    static RedFlujo ejemploSeisNodos() {
        int n = 6, s = n - 1, t = n - 2;
        RedFlujo r = new RedFlujo(n, s, t);
        r.agregarArista(s, 0, 10); r.agregarArista(s, 1, 10);
        r.agregarArista(2, t, 10); r.agregarArista(3, t, 10);
        r.agregarArista(0, 1, 2);  r.agregarArista(0, 2, 4);
        r.agregarArista(0, 3, 8);  r.agregarArista(1, 3, 9);
        r.agregarArista(3, 2, 6);
        return r;
    }

    static RedFlujo ejemploOnceNodos() {
        int n = 11, s = n - 1, t = n - 2;
        RedFlujo r = new RedFlujo(n, s, t);
        r.agregarArista(s, 0, 5);  r.agregarArista(s, 1, 10); r.agregarArista(s, 2, 15);
        r.agregarArista(0, 3, 10); r.agregarArista(1, 0, 15); r.agregarArista(1, 4, 20);
        r.agregarArista(2, 5, 25); r.agregarArista(3, 4, 25); r.agregarArista(3, 6, 10);
        r.agregarArista(3, 7, 20); r.agregarArista(4, 2, 5);  r.agregarArista(4, 7, 30);
        r.agregarArista(5, 7, 20); r.agregarArista(5, 8, 10); r.agregarArista(7, 8, 15);
        r.agregarArista(6, t, 5);  r.agregarArista(7, t, 15); r.agregarArista(8, t, 10);
        return r;
    }

   
    static RedFlujo redAleatoria(int n, double densidad, int capMax, long semilla) {
        Random rnd = new Random(semilla);
        RedFlujo r = new RedFlujo(n, 0, n - 1);
        for (int u = 0; u < n; u++)
            for (int v = 0; v < n; v++)
                if (u != v && rnd.nextDouble() < densidad)
                    r.agregarArista(u, v, 1 + rnd.nextInt(capMax));
        return r;
    }
}