/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto;


public abstract class AlgoritmoFlujo {
    protected long aumentos;
    protected long fases;
    protected long aristasExaminadas;

    public abstract String nombre();

  
    public final long resolver(RedFlujo red) {
        red.reiniciarFlujos();
        reiniciarContadores();
        return ejecutar(red);
    }


    final void reiniciarContadores() {
        aumentos = 0;
        fases = 0;
        aristasExaminadas = 0;
    }

    protected abstract long ejecutar(RedFlujo red);

    public long getAumentos() { return aumentos; }
    public long getFases() { return fases; }
    public long getAristasExaminadas() { return aristasExaminadas; }
}