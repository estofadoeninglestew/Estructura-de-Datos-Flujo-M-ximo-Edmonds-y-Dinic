/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto;


import java.util.Arrays;
import java.util.Locale;

public class Experimento {

    static final double[] DENSIDADES = {0.05, 0.20};
    static final String[] TIPOS = {"aleatoria", "capas"};
    static final int CAP_MAX_ALEATORIA = 100;
    static final int CORRIDAS_CALENTAMIENTO = 30;

    public static void main(String[] args) {
        int semillas = args.length > 0 ? Integer.parseInt(args[0]) : 10;
        int repeticiones = args.length > 1 ? Integer.parseInt(args[1]) : 7;
        int[] tamanios = args.length > 2
                ? Arrays.stream(args[2].split(",")).mapToInt(Integer::parseInt).toArray()
                : new int[]{100, 200, 400, 800, 1600};

        System.out.println("Java " + System.getProperty("java.version")
                + " | CPUs: " + Runtime.getRuntime().availableProcessors()
                + " | memoria maxima JVM: " + Runtime.getRuntime().maxMemory() / (1024 * 1024) + " MB");

        AlgoritmoFlujo[] algoritmos = {new EdmondsKarp(), new Dinic()};
        calentar(algoritmos);

        System.out.printf("%-10s %-5s %-5s %-7s %-7s %-9s %-13s %-8s %-9s %-6s %-13s %-12s%n",
                "Tipo", "Dens", "V", "Semilla", "Nodos", "Aristas", "Algoritmo", "Flujo",
                "Aumentos", "Fases", "Aristas exam.", "Tiempo (ms)");
        for (String tipo : TIPOS) {
            for (double dens : DENSIDADES) {
                for (int v : tamanios) {
                    for (int s = 1; s <= semillas; s++) {
                        long semilla = s;
                        RedFlujo red = generar(tipo, v, dens, semilla);
                        while (algoritmos[1].resolver(red) == 0) {
                            semilla += 1000;
                            red = generar(tipo, v, dens, semilla);
                        }
                        medir(tipo, dens, v, semilla, red, algoritmos, repeticiones);
                    }
                }
            }
        }
    }

    static RedFlujo generar(String tipo, int v, double dens, long semilla) {
        return tipo.equals("aleatoria")
                ? GeneradorRedes.aleatoria(v, dens, CAP_MAX_ALEATORIA, semilla)
                : GeneradorRedes.porCapas(v, dens, semilla);
    }

    static void calentar(AlgoritmoFlujo[] algoritmos) {
        for (int i = 0; i < CORRIDAS_CALENTAMIENTO; i++) {
            RedFlujo red = (i % 2 == 0)
                    ? GeneradorRedes.aleatoria(100, 0.10, CAP_MAX_ALEATORIA, i)
                    : GeneradorRedes.porCapas(100, 0.10, i);
            for (AlgoritmoFlujo a : algoritmos) a.resolver(red);
        }
    }

 
    static void medir(String tipo, double dens, int v, long semilla, RedFlujo red,
                      AlgoritmoFlujo[] algoritmos, int repeticiones) {
        long flujoRef = -1;
        boolean[] corteRef = null;
        for (AlgoritmoFlujo a : algoritmos) {
            double mejorNs = Double.MAX_VALUE;
            long flujo = 0;
            for (int r = 0; r < repeticiones; r++) {
                red.reiniciarFlujos();
                a.reiniciarContadores();
                long ini = System.nanoTime();
                flujo = a.ejecutar(red);
                long fin = System.nanoTime();
                mejorNs = Math.min(mejorNs, fin - ini);
            }
            boolean[] corte = red.alcanzablesDesdeFuente();
            if (corteRef == null) {
                flujoRef = flujo;
                corteRef = corte;
            } else if (flujo != flujoRef || !Arrays.equals(corte, corteRef)) {
                throw new IllegalStateException("Resultados distintos entre algoritmos: " + tipo
                        + " V=" + v + " dens=" + dens + " semilla=" + semilla);
            }
            System.out.printf(Locale.ROOT, "%-10s %-5.2f %-5d %-7d %-7d %-9d %-13s %-8d %-9d %-6d %-13d %-12.4f%n",
                    tipo, dens, v, semilla, red.getNumNodos(), red.getNumAristas(), a.nombre(),
                    flujo, a.getAumentos(), a.getFases(), a.getAristasExaminadas(), mejorNs / 1e6);
        }
    }
}

