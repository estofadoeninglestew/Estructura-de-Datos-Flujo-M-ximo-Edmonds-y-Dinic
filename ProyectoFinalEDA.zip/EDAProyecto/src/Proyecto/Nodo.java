/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto;

import java.util.ArrayList;
import java.util.List;


public class Nodo {
    public final int id;
    public final List<Arista> aristas = new ArrayList<>();

    Nodo(int id) {
        this.id = id;
    }
}